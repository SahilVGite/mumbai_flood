import BMCLogo from "./BMC logo.png";
import HDFCLogo from "./HDFC-Ergo-logo.png";
import IITBombayLogo from "./IIT Bombay Logo.png";
import ImdLogo from "./imd_logo_enamble.png";
import MCMCRLogo from "./MCMCR.png";

export{
    BMCLogo,
    HDFCLogo,
    IITBombayLogo,
    ImdLogo,
    MCMCRLogo,
}